using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Spark.Templates.Razor.Pages.Error
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Spark.Templates.Razor.Pages.Error
{
    public class PageNotFoundModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

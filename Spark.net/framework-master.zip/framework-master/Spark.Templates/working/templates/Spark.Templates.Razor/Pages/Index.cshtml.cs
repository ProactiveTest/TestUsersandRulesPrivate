﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Spark.Templates.Razor.Pages
{
	public class IndexModel : PageModel
	{
		public void OnGet()
		{
		}
	}
}
﻿using Spark.Library.Mail;

namespace Spark.Templates.Api.Application.Mail
{
    public class GenericMailable : Mailable<string>
    {
        public override void Build() { }
    }
}

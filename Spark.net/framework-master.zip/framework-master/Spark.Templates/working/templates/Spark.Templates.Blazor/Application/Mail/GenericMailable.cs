﻿using Spark.Library.Mail;

namespace Spark.Templates.Blazor.Application.Mail;

public class GenericMailable : Mailable<string>
{
    public override void Build() { }
}

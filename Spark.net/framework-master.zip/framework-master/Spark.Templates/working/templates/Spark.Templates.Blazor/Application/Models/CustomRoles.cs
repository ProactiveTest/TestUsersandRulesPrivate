﻿namespace Spark.Templates.Blazor.Application.Models;

public static class CustomRoles
{
    public const string Admin = nameof(Admin);
    public const string User = nameof(User);
}

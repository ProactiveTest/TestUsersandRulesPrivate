﻿using Spark.Library.Mail;

namespace Spark.Templates.Mvc.Application.Mail
{
    public class GenericMailable : Mailable<string>
    {
        public override void Build() { }
    }
}

﻿using Spark.Library.Environment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazorSpark.Tests.Mail
{
	[TestClass]
	public class MailTest
	{
		//[TestMethod]
		//public void CanLoadConfig()
		//{
		//	EnvManager.LoadConfig();
		//	Assert.IsTrue(Env.Get("APP_NAME") == "SparkTests");
		//}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spark.Library.Logging
{
    internal class LogChannels
    {
        public const string file = nameof(file);
        public const string console = nameof(console);
    }
}

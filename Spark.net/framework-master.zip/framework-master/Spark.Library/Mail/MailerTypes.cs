﻿namespace Spark.Library.Mail
{
	public class MailerTypes
	{
		public const string file = nameof(file);
		public const string smtp = nameof(smtp);
	}
}

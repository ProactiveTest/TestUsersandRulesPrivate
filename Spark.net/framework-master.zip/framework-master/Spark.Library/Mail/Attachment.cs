﻿namespace Spark.Library.Mail
{
	public class Attachment
	{
		public byte[] Bytes { get; set; }
		public string Name { get; set; }
	}
}
